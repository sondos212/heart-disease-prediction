# app.py
import streamlit as st
import pandas as pd
import joblib
import os

st.set_page_config(page_title="Heart Disease Prediction", layout="centered")
st.title(" Heart Disease Prediction App")

# Load model safely
import joblib

model_path = r"C:\Users\sondo\OneDrive - Alexandria National University\Desktop\Sprints final project\heart+disease\models\final_model.pkl"
model = joblib.load(model_path)

if not os.path.exists(model_path):
    st.error(" Model file not found! Please train and save the model first.")
    st.stop()

model = joblib.load(model_path)

# Dynamically get feature names
features = model.feature_names_in_

st.subheader("Enter Patient Information")

# Create input fields dynamically
user_data = {}
for feature in features:
    if feature.lower() in ["sex", "cp", "fbs", "restecg", "exang", "slope", "thal"]:  
        # Categorical/binary features
        user_data[feature] = st.number_input(f"{feature}", min_value=0, max_value=5, step=1, value=0)
    else:
        # Continuous features
        user_data[feature] = st.number_input(f"{feature}", min_value=0.0, value=0.0)

# Convert to DataFrame
input_df = pd.DataFrame([user_data])

# Prediction
if st.button(" Predict"):
    prediction = model.predict(input_df)[0]
    probability = model.predict_proba(input_df)[0][1]

    st.write("###  Prediction Result:")
    if prediction == 1:
        st.error(f" High Risk of Heart Disease (Probability: {probability:.2f})")
    else:
        st.success(f" No Heart Disease Detected (Probability: {probability:.2f})")
